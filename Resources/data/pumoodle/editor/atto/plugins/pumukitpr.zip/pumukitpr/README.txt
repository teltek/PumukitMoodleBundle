PuMuKIT Atto plugin for Moodle
==============================

_experimental_


Template in https://github.com/justinhunt/moodle-atto_newtemplate/


Doc:
 * https://docs.moodle.org/dev/Grunt
 * https://docs.moodle.org/dev/Atto
