Pmkpersonalvideos resource module

This module allows to create a new resource with an embedded video
brought by the pumukit server.

Adapted from the module template:
http://docs.moodle.org/dev/NEWMODULE_Documentation 
https://github.com/moodlehq/moodle-mod_newmodule

