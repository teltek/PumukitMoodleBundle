<?php 
// $Id: filter_pumukit.php
// Language string for filter/pumukit.
 
$string['filtername'] = 'Pumukit filter';

// Examples from helloworld filter
// $string['word'] = 'The thing to greet';
// $string['configword'] = 'The hello world filter will add the word \'hello\' in front of every occurrence of this word in any content.';
