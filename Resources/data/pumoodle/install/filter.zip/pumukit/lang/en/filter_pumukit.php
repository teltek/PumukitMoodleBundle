<?php
// $Id: filter_pumukit.php
// Language string for filter/pumukit.

$string['filtername'] = 'Pumukit filter';
$string['secret'] = 'PuMuKIT secret';
$string['secret_description'] = 'Moodle will use this shared secret to encrypt queries to the pumukit server';
$string['iframe_singlevideo_width'] = 'Single Video Width';
$string['iframe_singlevideo_height'] = 'Single Video Height';
$string['iframe_multivideo_width'] = 'Multi Video Width';
$string['iframe_multivideo_height'] = 'Multi Video Height';
$string['css_notvalid'] = "Value not valid: Use a number followed by an unit ('px', 'em' or '%').";
