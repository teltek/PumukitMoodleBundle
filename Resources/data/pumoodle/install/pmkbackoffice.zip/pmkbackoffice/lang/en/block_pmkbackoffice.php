<?php
$string['linktopage'] = 'Go to PuMuKIT - Media Manager';
$string['pagetitle'] = 'PuMuKIT - Media Manager';
$string['pagenotfoundtext'] = 'The \'pmksearch\' repository instance was not found. Maybe the wrong id was added as \'instance_id\' parameter?';
$string['pluginname'] = 'PuMuKIT - Media Manager block';
$string['pmkbackoffice'] = 'PuMuKIT - Media Manager';
$string['pmkbackoffice:addinstance'] = 'Add a new PuMuKIT - Media Manager block';
$string['pmkbackoffice:myaddinstance'] = 'Add a new PuMuKIT - Media Manager to the My Moodle page';
