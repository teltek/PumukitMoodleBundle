<?php
$string['linktopage'] = 'Ir al Media Manager de PuMuKIT';
$string['pagetitle'] = 'PuMuKIT - Media Manager';
$string['pagenotfoundtext'] = 'La instancia del repositorio \'pmksearch\' no fue encontrada. ¿Quizás se envió el id equivocado como parámetro \'instance_id\'?';
$string['pluginname'] = 'PuMuKIT - Media Manager block';
$string['pmkbackoffice'] = 'PuMuKIT - Media Manager';
$string['pmkbackoffice:addinstance'] = 'Añadir un nuevo \'block\' PuMuKIT - Media Manager';
$string['pmkbackoffice:myaddinstance'] = 'Añadir un nuevo PuMuKIT - Media Manager a mi página de Moodle';
